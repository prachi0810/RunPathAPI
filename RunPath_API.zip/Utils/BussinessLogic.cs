﻿using RunPath_WebAPI.Model;
using RunPath_WebAPI.Model.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RunPath_WebAPI.Utils
{
    public class BussinessLogic
    {
        private readonly IJsonClient client;

        public BussinessLogic(IJsonClient client)
        {
            this.client = client;
        }
        public async Task<IEnumerable<IAlbum>> GetAllAsync()
        {
            return await GetCoreAsync();
        }

        public async Task<IEnumerable<IAlbum>> GetFilteredAsync(int userId)
        {
            return await GetCoreAsync(userId);
        }

        private async Task<IEnumerable<IAlbum>> GetCoreAsync(int? userId = null)
        {
            var jsonAlbums = await this.client.GetAlbumAsync();

            var jsonPhotos = await this.client.GetPhotosAsync();

            var results = new List<IAlbum>();

            if (userId != null)
                jsonAlbums = jsonAlbums.Where(j => j.UserID == userId);

            foreach (var jsonAlbum in jsonAlbums)
            {
                var item = new Album
                {
                    Id = jsonAlbum.Id,
                    UserID = jsonAlbum.UserID,
                    Title = jsonAlbum.Title,
                    Photos = jsonPhotos
                                    .Where(p => p.AlbumId == jsonAlbum.Id)
                                    .Select(i => new Photos
                                    {
                                        Id = i.Id,
                                        AlbumId = i.AlbumId,
                                        ThumbnairUrl = i.ThumbnairUrl,
                                        Title = i.Title,
                                        Url = i.Url,
                                    }).ToList()
                };

                results.Add(item);
            }

            return results;
        }
    }
}
