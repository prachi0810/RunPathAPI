﻿using RunPath_WebAPI.Model.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RunPath_WebAPI.Utils
{
    public interface IJsonClient
    {
        Task<IEnumerable<JsonAlbum>> GetAlbumAsync();
        Task<IEnumerable<JsonPhotos>> GetPhotosAsync();
    }
}
