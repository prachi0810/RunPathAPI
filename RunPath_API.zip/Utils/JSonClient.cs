﻿using RunPath_WebAPI.Model.Json;
using RunPath_WebAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace RunPath_WebAPI.Utils
{
    public class JSonClient : HttpClient, IJsonClient
    {
        public JSonClient()
        {
            this.BaseAddress = new Uri(Environment.GetEnvironmentVariable("JsonPlaceholderUrl"));
        }

        public async Task<IEnumerable<JsonAlbum>> GetAlbumAsync()
        {
            var albumPath = Environment.GetEnvironmentVariable("AlbumPath");
            var response = await this.GetAsync(albumPath);

            return await response.Content.ReadAsAsync<IEnumerable<JsonAlbum>>();
        }
        public async Task<IEnumerable<JsonPhotos>> GetPhotosAsync()
        {
            var photoPath = Environment.GetEnvironmentVariable("PhotoPath");
            var response = await this.GetAsync(photoPath);

            return await response.Content.ReadAsAsync<IEnumerable<JsonPhotos>>();
        }
    }
}
