﻿using Microsoft.AspNetCore.Mvc;
using RunPath_WebAPI.Model.Interface;
using RunPath_WebAPI.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RunPath_WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumPhotoController : ControllerBase, IRESTJsonPlaceholderApi
    {
        [HttpGet]
        public async Task<ActionResult<IEnumerable<IAlbum>>> Get()
        {
            try
            {
                JSonClient client = new JSonClient();
                BussinessLogic logic = new BussinessLogic(client);

                IEnumerable<IAlbum> response = await logic.GetAllAsync();

                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); //+ " " + ex.StackTrace    
            }
        }

        [HttpGet("{userId}")]
        public async Task<ActionResult<IEnumerable<IAlbum>>> Get(int userId)
        {
            try
            {
                JSonClient client = new JSonClient();
                BussinessLogic logic = new BussinessLogic(client);

                IEnumerable<IAlbum> response = await logic.GetFilteredAsync(userId);

                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message); //+ " " + ex.StackTrace    
            }
        }
    }
}
