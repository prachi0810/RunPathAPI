﻿using RunPath_WebAPI.Model.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RunPath_WebAPI.Model
{
    public class Album : IAlbum
    {
        public int UserID { get; set; }
        public int Id { get; set; }
        public string Title { get; set; }
        public IEnumerable<Photos> Photos { get; set; }
    }
}
