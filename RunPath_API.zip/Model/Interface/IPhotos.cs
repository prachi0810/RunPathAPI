﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RunPath_WebAPI.Model.Interface
{
    public interface IPhotos
    {
        int AlbumId { get; set; }
        int Id { get; set; }
        string Title { get; set; }
        Uri Url { get; set; }
        Uri ThumbnairUrl { get; set; }
    }
}
