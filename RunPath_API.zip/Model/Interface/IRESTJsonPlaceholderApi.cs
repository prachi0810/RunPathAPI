﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RunPath_WebAPI.Model.Interface
{
    interface IRESTJsonPlaceholderApi
    {
        Task<ActionResult<IEnumerable<IAlbum>>> Get();
        Task<ActionResult<IEnumerable<IAlbum>>> Get(int userId);
    }
}
